# Obter os valores de entrada
HT = float(input("Digite o número de horas trabalhadas no mês: "))
VH = float(input("Digite o valor da hora trabalhada: R$ "))
PD = float(input("Digite o percentual de desconto: "))

# Calcular o salário bruto
SB = HT * VH

# Calcular o total de desconto
TD = (PD / 100) * SB

# Calcular o salário líquido
SL = SB - TD

# Exibir os resultados
print(f"\nHoras Trabalhadas: {HT} horas")
print(f"Salário Bruto: R$ {SB:.2f}")
print(f"Desconto: R$ {TD:.2f}")
print(f"Salário Líquido: R$ {SL:.2f}")
