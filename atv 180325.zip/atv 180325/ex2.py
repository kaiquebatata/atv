# Ler a hora e os minutos
hora = int(input("Digite a hora: "))
minutos = int(input("Digite os minutos: "))

# Calcular o total de minutos desde o início do dia
minutos_totais = (hora * 60) + minutos

# Exibir o resultado
print(f"Desde o início do dia, se passaram {minutos_totais} minutos.")

