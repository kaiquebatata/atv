# Ler dois números reais
numero1 = float(input("Digite o primeiro número: "))
numero2 = float(input("Digite o segundo número: "))

# Calcular o resto da divisão
resto = numero1 % numero2

# Exibir o resultado
print(f"O resto da divisão de {numero1} por {numero2} é: {resto}")
 
