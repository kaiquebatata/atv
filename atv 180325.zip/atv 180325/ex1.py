# Ler a cotação do dólar e o valor em dólares
cotacao_dolar = float(input("Digite a cotação do dólar: R$ "))
valor_dolares = float(input("Digite o valor em dólares: $ "))

# Calcular o valor equivalente em Reais
valor_reais = cotacao_dolar * valor_dolares

# Exibir o valor em Reais
print(f"O valor equivalente em Reais é: R$ {valor_reais:.2f}")
