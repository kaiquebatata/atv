# Ler o valor gasto pelo cliente
gasto_cliente = float(input("Digite o valor gasto pelo cliente no restaurante (R$): "))

# Calcular a gorjeta de 10%
gorjeta = gasto_cliente * 0.10

# Calcular o valor total a ser pago
total_a_pagar = gasto_cliente + gorjeta

# Exibir o resultado
print(f"O valor total a ser pago, incluindo a gorjeta de 10%, é: R$ {total_a_pagar:.2f}")
